﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для TableTarif.xaml
    /// </summary>
    public partial class TableTarif : Page
    {
        public TableTarif()
        { 
            InitializeComponent();
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            CmbFiltrTarif.ItemsSource = cellularproviderEntities.GetContext().Country.ToList();
            CmbFiltrTarif.SelectedValuePath = "IDCountry";
            CmbFiltrTarif.DisplayMemberPath = "CountryName";

        }

    private void btnEdit_Click(object sender, RoutedEventArgs e)
    //Редактирование пользователей
    {
            this.NavigationService.Navigate(new Pages.AddEditTarif((sender as Button).DataContext as Tarif));
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    // Добавление пользователей
    {
            this.NavigationService.Navigate(new Pages.AddEditTarif(null));
    }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        //Удаление нескольких пользователей
        var personForRemoving = DGridTarif.SelectedItems.Cast<Tarif>().ToList();
        //Подтверждение удаления
        if (MessageBox.Show($"Удалить {personForRemoving.Count()} тарифов?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        {
            try
            {
                    //удаление
                cellularproviderEntities.GetContext().Tarif.RemoveRange(personForRemoving);
                cellularproviderEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные удалены");
                    DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }

    private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {//Динамиеское отображение добавленных или изменённых данных
        if (Visibility == Visibility.Visible)
        {
            cellularproviderEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
        }
    }

    private void BtnResetAll_Click(object sender, RoutedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
    }

    private void CmbFiltrTarif_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        int id = Convert.ToInt32(CmbFiltrTarif.SelectedValue);
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.Country.IDCountry == id).ToList();
    }

    private void RbUp_Checked(object sender, RoutedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.OrderBy(x => x.TarifName).ToList();
    }

    private void RbDown_Checked(object sender, RoutedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.OrderByDescending(x => x.TarifName).ToList();
    }
    private void RbChecked(object sender, RoutedEventArgs e)
        {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.Internet < 10).ToList();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.TarifName.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
    }

        private void price_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int pr1 = int.Parse(priceSearch.Text);
                DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.Price < pr1).ToList();
            }
            catch (Exception ex)
            {
               
                 MessageBox.Show("Ошибка ввода!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }


        }

        private void printTarifs_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new PrintPage());
        }
    }
}

