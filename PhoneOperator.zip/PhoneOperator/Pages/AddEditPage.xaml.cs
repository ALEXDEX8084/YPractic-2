﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneOperator.Classes;
using Word = Microsoft.Office.Interop.Word;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Runtime.InteropServices;


namespace PhoneOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        private Abonent _currentperson = new Abonent(); //экземпляр добавляемого пользователя
        public AddEditPage(Abonent selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
            CmbFiltrTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            CmbFiltrTarif.SelectedValuePath = "IDTarif";
            CmbFiltrTarif.DisplayMemberPath = "TarifName";

        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.SurName))
                error.AppendLine("Укажите Фамилию");
            if (string.IsNullOrWhiteSpace(_currentperson.FirstName))
                error.AppendLine("Укажите Имя");
            if (string.IsNullOrWhiteSpace(patron.Text))
                error.AppendLine("Укажите Отчество");
            if (string.IsNullOrWhiteSpace(passport.Text))
                error.AppendLine("Укажите паспорт");
            if (string.IsNullOrWhiteSpace(phonenumber.Text))
                error.AppendLine("Укажите номер телефона");
            if (string.IsNullOrWhiteSpace(CmbFiltrTarif.Text))
                error.AppendLine("Укажите Тариф");
            //if (cellularproviderEntities.GetContext().Abonent.Contains());
            //error.AppendLine("Номер телефона уже занят");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDAbonent == 0)
                cellularproviderEntities.GetContext().Abonent.Add(_currentperson);//Добавить в контекст
            try
            {

                cellularproviderEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }


        private void CmbFiltrTarif_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }

}
