﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Interaction logic for AddEditCountry.xaml
    /// </summary>
    public partial class AddEditCountry : Page
    {
        private Country _currentperson = new Country(); //экземпляр добавляемого пользователя
        public AddEditCountry(Country selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;

        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.CountryName))
                error.AppendLine("Укажите страну");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDCountry == 0)
                cellularproviderEntities.GetContext().Country.Add(_currentperson);//Добавить в контекст
            try
            {

                cellularproviderEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void CmbFiltrTarifAD_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }

}
