﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneOperator.Classes;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Interaction logic for PageStatistics.xaml
    /// </summary>
    public partial class PageStatistics : Page
    {
        public PageStatistics()
        {
            InitializeComponent();
            DGridTarifCount.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            List<TarifCountClass> listaboncnt = new List<TarifCountClass>();
            foreach (int t in cellularproviderEntities.GetContext().Tarif.Select(x => x.IDTarif).ToList())
            {
                TarifCountClass abon = new TarifCountClass (
                  (
                    cellularproviderEntities.GetContext().Abonent.Where(x => x.IDTarif == t).Count()
                    ));

                listaboncnt.Add(abon);
            }    
            DGridTarifCount2.ItemsSource = listaboncnt;
        }
    }
}
