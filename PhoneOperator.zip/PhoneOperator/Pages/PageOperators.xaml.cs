﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneOperator.Classes;
using PhoneOperator.Pages;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Interaction logic for PageOperators.xaml
    /// </summary>
    public partial class PageOperators : Page
    {
        public PageOperators()
        {
            InitializeComponent();
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.ToList();
            CmbFiltrGroup.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            CmbFiltrGroup.SelectedValuePath = "IDTarif";
            CmbFiltrGroup.DisplayMemberPath = "TarifName";

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.AddEditPage((sender as Button).DataContext as Abonent));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.AddEditPage(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких 
            var personForRemoving = DGridAbonents.SelectedItems.Cast<Abonent>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} абонентов?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    cellularproviderEntities.GetContext().Abonent.RemoveRange(personForRemoving);
                    cellularproviderEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                cellularproviderEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.ToList();
        }

        private void CmbFiltrGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrGroup.SelectedValue);
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.IDTarif == id).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.OrderBy(x => x.SurName).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.OrderByDescending(x => x.SurName).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedIndex == 0)
            {
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.Country.CountryName == "Россия").ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 1)
            {
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.Country.CountryName == ("Румыния")).ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 2)
            {
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.Country.CountryName == ("Италия")).ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 3)
            {
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.Country.CountryName == ("Франция")).ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 4)
            {
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.Country.CountryName == ("Германия")).ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 5)
            {
                DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.Country.CountryName == ("Китай")).ToList();
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.SurName.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void TxtSearchAb_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridAbonents.ItemsSource = cellularproviderEntities.GetContext().Abonent.Where(x => x.Tarif.TarifName.ToLower().Contains(TxtSearchAb.Text.ToLower())).ToList();
        }

        private void BtnAVG_Click(object sender, RoutedEventArgs e)
        {
            decimal? sum = cellularproviderEntities.GetContext().Abonent.Average(x => x.Tarif.Price);
            countrez.Text = $"{sum.ToString()} руб.";
        }

        private void Btntableadt_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new PageStatistics());
        }

    }
}
