﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Interaction logic for PrintPage.xaml
    /// </summary>
    public partial class PrintPage : Page
    {
        public PrintPage()
        {
            InitializeComponent();
            DGridTarifp.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
        }

        private void PrintBtn_Click(object sender, RoutedEventArgs e)
        {
            //объект Excel
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 2;
            //ячейка
            
            Excel.Range _excelCells1 = (Excel.Range)worksheet.get_Range("A1", "D1").Cells;
            // Производим объединение
            _excelCells1.Merge(Type.Missing);
            worksheet.Cells[1, 1] = "Выгодные тарифы, интернет по всему миру.";
            _excelCells1.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            _excelCells1.Font.Bold = true;
            worksheet.Cells[1][indexRows] = "Страна";
            worksheet.Cells[2][indexRows] = "Тариф";
            worksheet.Cells[3][indexRows] = "Цена";
            worksheet.Cells[4][indexRows] = "Интернет(ГБ)";
            //список пользователей
            var printItems = cellularproviderEntities.GetContext().Tarif.ToList();
            //цикл по данным из таблицы
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = item.Country.CountryName;
                worksheet.Cells[2][indexRows + 1] = item.TarifName;
                worksheet.Cells[3][indexRows + 1] = item.Price;
                worksheet.Cells[4][indexRows + 1] = item.Internet;
                indexRows++;
            }
            Excel.Range range = worksheet.Range[worksheet.Cells[1][indexRows + 1],
        worksheet.Cells[5][indexRows + 1]];
            range.ColumnWidth = 20; //ширина столбцов
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;//выравнивание по левому краю
                                                                    
            Excel.Range _excelCells2 = (Excel.Range) worksheet.Range[worksheet.Cells[1, indexRows + 2], worksheet.Cells[4, indexRows + 2]];
            // Производим объединение
            _excelCells2.Merge(Type.Missing);
            worksheet.Cells[1][indexRows + 2] = "Звонки внутри страны безлимитны и интернет трафик работает без роуминга.";
            worksheet.Cells[1][indexRows + 3] = "Звонки на номера служб спасения за границей АБСОЛЮТНО бесплатны";
            worksheet.Cells[1][indexRows + 4] = "Иные звонки работают через роуминг и плата будет списываться с телефона по минутно!";
            _excelCells2.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            // показать Excel
            app.Visible = true;
        }
    }
}
